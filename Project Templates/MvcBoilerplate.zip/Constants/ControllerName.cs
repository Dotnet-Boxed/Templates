﻿namespace $safeprojectname$.Constants
{
    public static class ControllerName
    {
        public const string Error = "Error";
        public const string Home = "Home";
    }
}