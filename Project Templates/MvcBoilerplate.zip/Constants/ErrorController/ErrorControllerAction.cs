﻿namespace $safeprojectname$.Constants
{
    public static class ErrorControllerAction
    {
        public const string NotFound = "NotFound";
        public const string Unauthorized = "Unauthorized";
    }
}