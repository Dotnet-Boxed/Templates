﻿namespace $safeprojectname$.Constants
{
    public static class ErrorControllerRoute
    {
        public const string GetNotFound = ControllerName.Error + "GetNotFound";
        public const string GetUnauthorized = ControllerName.Error + "Unauthorized";
    }
}