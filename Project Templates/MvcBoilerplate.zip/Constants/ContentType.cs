﻿namespace $safeprojectname$.Constants
{
    public static class ContentType
    {
        public const string Text = "text/plain";
        public const string Xml = "application/xml";
    }
}