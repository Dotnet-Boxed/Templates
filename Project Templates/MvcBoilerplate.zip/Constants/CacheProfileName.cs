﻿namespace $safeprojectname$.Constants
{
    public static class CacheProfileName
    {
        public const string RobotsText = "RobotsText";
        public const string SitemapXml = "SitemapXml";
    }
}