﻿namespace $safeprojectname$.Constants
{
    public class Application
    {
        public const string Name = "Learning";
    }
}