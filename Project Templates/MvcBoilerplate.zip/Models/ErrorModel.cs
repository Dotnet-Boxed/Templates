﻿namespace $safeprojectname$.Models
{
    public class ErrorModel
    {
        public string RequestedUrl { get; set; }

        public string ReferrerUrl { get; set; }
    }
}