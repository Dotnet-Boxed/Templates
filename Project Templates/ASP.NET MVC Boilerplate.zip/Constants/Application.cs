﻿namespace $safeprojectname$.Constants
{
    public class Application
    {
        public const string Name = "ASP.NET MVC Boilerplate";
    }
}